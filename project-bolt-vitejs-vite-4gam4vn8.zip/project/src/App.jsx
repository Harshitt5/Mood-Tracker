import { useState } from 'react';

const emojis = [
  { emoji: '😄', mood: 'Happy', color: 'bg-yellow-300' },
  { emoji: '😐', mood: 'Neutral', color: 'bg-gray-300' },
  { emoji: '😢', mood: 'Sad', color: 'bg-blue-300' },
  { emoji: '😠', mood: 'Angry', color: 'bg-red-300' },
];

export default function App() {
  const today = new Date().toISOString().split('T')[0];
  const [moods, setMoods] = useState({});
  const [selectedDate, setSelectedDate] = useState(today);

  const handleMoodSelect = (mood) => {
    setMoods({ ...moods, [selectedDate]: mood });
  };

  const getMoodColor = (date) => {
    const mood = moods[date];
    const found = emojis.find((e) => e.mood === mood);
    return found ? found.color : 'bg-white';
  };

  const generatePast7Days = () => {
    const days = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      days.push(d.toISOString().split('T')[0]);
    }
    return days;
  };

  return (
    <div className="p-6 max-w-md mx-auto text-center">
      <h1 className="text-2xl font-bold mb-4">Mood Tracker</h1>

      <input
        type="date"
        className="mb-4 p-2 border rounded"
        value={selectedDate}
        onChange={(e) => setSelectedDate(e.target.value)}
      />

      <div className="flex justify-center gap-3 mb-4">
        {emojis.map(({ emoji, mood }) => (
          <button
            key={mood}
            onClick={() => handleMoodSelect(mood)}
            className="text-2xl hover:scale-110 transition"
            title={mood}
          >
            {emoji}
          </button>
        ))}
      </div>

      <h2 className="text-lg font-semibold mb-2">Past 7 Days</h2>
      <div className="grid grid-cols-7 gap-2">
        {generatePast7Days().map((date) => (
          <div key={date} className={`p-4 rounded ${getMoodColor(date)} border`}>
            <p className="text-xs">{date.slice(5)}</p>
            <p>{moods[date] ? emojis.find(e => e.mood === moods[date]).emoji : '❓'}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
